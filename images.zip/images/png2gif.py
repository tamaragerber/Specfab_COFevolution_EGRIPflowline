import glob
import os
from moviepy.editor import *


gif_name = 'EGRIP_fabricEvolution'
file_list = glob.glob('*.png') # Get all the pngs in the current directory
list.sort(file_list, key=lambda t: os.stat(t).st_mtime)
print(file_list)
with open('image_list.txt', 'w') as file:
    for item in file_list:
        file.write("%s\n" % item)

os.system('convert @image_list.txt {}.gif'.format(gif_name)) # On windows convert is 'magick'


